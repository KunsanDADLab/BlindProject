package com.example.blindproject2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;

import android.speech.tts.TextToSpeech;
import static android.speech.tts.TextToSpeech.ERROR;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.io.DataOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    public static int token = 1;
    private int count=0;
    private int port =;//port
    private String host = "";//서버 ip
    //private String host = "";//서버 ip
    //private String host = "";//서버 ip

    //public static final int REQUEST_TAKE_PHOTO = 10;
    public static final int REQUEST_PERMISSION = 11;
    private TextToSpeech tts; //TTS 변수 선언
    CameraSurfaceView surfaceView;

    FileOutputStream output=null;
    Bitmap resizedBitmap=null;

    //0914
    Socket socket;
    DataOutputStream dos;
    DataInputStream dis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        //파일 권한 묻기
        checkPermission();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(this, "외부 저장소 사용을 위해 읽기/쓰기 필요", Toast.LENGTH_SHORT).show();
                }

                requestPermissions(new String[]
                        {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
            }
        }



        //btn_submit = findViewById(R.id.btn_submit);
        //imageView = findViewById(R.id.imageView);
        surfaceView = findViewById(R.id.surfaceView);
        ImageButton butt_play=findViewById(R.id.butt_play);
        butt_play.bringToFront();
        //음성 인식

        tts=new TextToSpeech(this,new TextToSpeech.OnInitListener(){
            @Override
            public void onInit(int status){
                if(status!= ERROR){
                    //언어를 선택한다
                    tts.setLanguage(Locale.KOREA);
                }
            }
        });

        butt_play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(count==0){
                    count=1;
                    //0914
                    new Thread(){
                        @Override
                        public void run(){
                            try {
                                socket = new Socket(host, port);
                                dos = new DataOutputStream(socket.getOutputStream());
                                dis = new DataInputStream(socket.getInputStream());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();

//                    tts.setSpeechRate(1.0f);
//                    tts.setPitch(1.0f);
                    capture(); //카메라 사진 캡쳐
                }
                else{
                    count=0;
                    try {
                        socket.close();
                        dos.close();
                        dis.close();
                    }
                    catch(Exception e){

                    }
                    finish();
                }

            }
        });


    }




    public void capture(){
        token = 0;

        surfaceView.capture(new Camera.PictureCallback() {

            @Override
            public void onPictureTaken(byte[] data, Camera camera) {
                //사진 찍은 결과가 byte[]로 전달된 것을 이미지뷰로 보여주기
                //bytearray 형식으로 전달
                //이걸이용해서 이미지뷰로 보여주거나 파일로 저장
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 8; // 8분의 1크기로 비트맵 객체 생성
                // 가져온 결과물을 비트맵 객체로 생성
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);


                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                int newWidth = 640;
                int newHeight = 640;

                float scaleWidth = ((float) newWidth) / width;
                float scaleHeight = ((float) newHeight) / height;

                Matrix matrix = new Matrix();

                matrix.postScale(scaleWidth, scaleHeight);

                matrix.postRotate(90);


                //Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
                resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);

                // 사진을 찍으면 미리보기가 중지되기 때문에 다시 시작하게 함
                camera.startPreview();

                //서버에 결과 보내기

                SocketThread thread = new SocketThread(host);
                thread.start();

//                try{
//                    //wait(4000);
//                    Thread.sleep(2000);
//                } catch (InterruptedException e) {
//                    Log.d("log ","sleep오류");
//                }

                while(token==0){
                    try{
                        wait();
                    }catch (Exception e){

                    }
                }
                capture();
            }
        });
    }


    public void ttsPlay(String msg) {
        tts.setSpeechRate(1.5f);
        tts.speak(msg, TextToSpeech.QUEUE_ADD, null);
        //tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null);
    }


    private void playSound(String msg){

        String result="";
        Map<String,Integer> mapE=new HashMap<>();//순서대로 하려면 LinkedHashMap<> =new LinkedHashMap<>()
        Map<String,Integer> mapW=new HashMap<>();
        String arr[]=msg.split("&");

        for(int a=0;a<arr.length;a++){
            if(arr[a].contains("E")){
                int temp=arr[a].length();
                String temp2=arr[a].substring(2,temp);
                if(mapE.containsKey(temp2)){
                    mapE.put(temp2,mapE.get(temp2)+1);
                }
                else{
                    mapE.put(temp2,1);
                }
            }//10m이내에 위험한 객체 배열 생성

            else if(arr[a].contains("W")){
                int temp=arr[a].length();
                String temp2=arr[a].substring(2,temp);
                if(mapW.containsKey(temp2)){
                    mapW.put(temp2,mapW.get(temp2)+1);
                }
                else{
                    mapW.put(temp2,1);
                }
            }//보행경로에 객체 배열 생성
        }

        if(mapE.size()!=0){
            result+=Tts("1");//result(String 변수)에 "전방 10미터 이내에" 문자열 추가
            for(Map.Entry<String,Integer> entryE:mapE.entrySet()) {//10m 이내 위험한 객체
                result+=Tts(entryE.getKey());
                if(entryE.getValue()!=1){
                    result+=entryE.getValue()+unit(entryE.getKey());
                }
            }
        }

        if(mapW.size()!=0){
            result+=Tts("2");//음성 재생 "보행자 경로에"
            for(Map.Entry<String,Integer> entryW:mapW.entrySet()) {//보행자 경로에 객체 안내
                result+=Tts(entryW.getKey());
                if(entryW.getValue()!=1){
                    result+=entryW.getValue()+unit(entryW.getKey());
                }
            }
        }
        if(result!="")ttsPlay(result);
    }

    private String Tts(String obj){//장애물 음성 안내 추가는 여기에서1
        //장애물
        String result="";
        switch(obj){
            case "1":
                result="10미터 ";
                break;
            case "2":
                result="보행경로 ";
                break;
            case "scooter":
                result="킥보드"; //scooter
                break;
            case "motorcycle":
                result="오토바이"; //motorcycle
                break;
            case "bicycle":
                result="자전거";//bicycle
                break;
            case "tree_trunk":
                result="나무";//tree_trunk
                break;
            case "fire_hydrant":
                result="소화전";//fire_hydrant
                break;
            case "car":
                result="승용차";//car
                break;
            case "bus":
                result="버스";//bus
                break;
            case "bench":
                result="벤치";//bench
                break;
            case "person":
                result="사람";//person
                break;
            case "grating":
                result="하수구";//grating
                break;
            case "bollard_u": //bollard 차량진입방지말뚝
                result="유자";
                break;
            case "bollard_stainless":
                result="스텐";
                break;
            case "bollard_rubber":
                result="고무";
                break;
            case "bollard_marble":
                result="대리석";
                break;
        }
        return result;
    }

    private String unit(String obj){//객체 안내 음성 추가하면 여기에 단위 추가2(끝)
        String result="";
        switch(obj){
            case "car":
            case "bus":
            case "motorcycle":
            case "bicycle":
            case "scooter":
            case "wheelchair":
                result="대";
                break;
            case "person":
                result="명";
                break;
            case "dog":
            case "cat":
                result="마리";
                break;
            default:result="개";
        }
        return result;
    }

    class SocketThread extends Thread {
        String host; //서버 IP
        //String filePath = "/storage/emulated/0/Pictures/toserver.jpg";
        //String filePath = "/sdcard/TOServer/toserver.jpg"; //핸드폰
        //String filePath = "/sdcard/Pictures/toserver.jpg";
        //Socket socket;

        public SocketThread(String host) {
            this.host = host;
        }

        //@Override
        public void run() {
            /*//0914
            try {
                socket = new Socket(host, port);//소켓 열어주기
                sendimg();
                socket.close();//소켓 해제
            } catch (IOException e) {
                //text.setText("IOException1 오류");
                Log.d("socketThread","IOException1 오류");
            }
             */
            sendimg();
        }

        public void sendimg() {
            try {


                ByteArrayOutputStream byteArray = new ByteArrayOutputStream();

                //0728
                resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArray);

                //byteArray.flush();
                byte[] bytes = byteArray.toByteArray();
                Log.d("log",bytes.toString());
                // text.setText(" " + bytes.toString());

                //0914
                //DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                //DataInputStream dis = new DataInputStream(socket.getInputStream());



                dos.writeUTF(Integer.toString(bytes.length)); //파일 크기 보냄
                dos.flush();

                dos.write(bytes);
                dos.flush();

                //--><-- 파이썬에서 결과받기
                bytes = new byte[20];
                dis.read(bytes, 0, 20);
                ByteBuffer b1 = ByteBuffer.wrap(bytes);
                b1.order(ByteOrder.LITTLE_ENDIAN);
                int length = b1.getInt();
                bytes = new byte[length];
                dis.read(bytes, 0, length);
                String msg = new String(bytes, "UTF-8");
                //text.setText("서버에서 온 결과 " + msg);
                Log.d("서버에서 온 결과 ",msg);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("서버에서 온 결과",msg);
                    }
                });

                playSound(msg); //결괏값 처리리
                token = 1;

                //0914
                //dos.close();
                //dis.close();

                //값 받아 tts
                /*
                tts.setPitch(2.0f);//음성 톤을 2.0배 올려준다.
                tts.setSpeechRate(1.0f);//읽는 속도는 기본 설정
                 */
                //QUEUE_FLUSH: 진행 중인 음성 종료하고 출력, QUEUE_ADD: 진행 중인 음성 뒤에 출력
            } catch (IOException e) {
            }


        }
    }



    @Override
    public void onResume() {
        super.onResume();
        checkPermission(); //권한체크
    }

    //권한 확인
    public void checkPermission() {
        int permissionCamera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int permissionRead = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        //권한이 없으면 권한 요청
        if (permissionCamera != PackageManager.PERMISSION_GRANTED
                || permissionRead != PackageManager.PERMISSION_GRANTED
                || permissionWrite != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                Toast.makeText(this, "이 앱을 실행하기 위해 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }

            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_PERMISSION: {
                // 권한이 취소되면 result 배열은 비어있다.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, "권한 확인", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(this, "권한 없음", Toast.LENGTH_LONG).show();
                    finish(); //권한이 없으면 앱 종료
                }
            }
        }
    }
}